"use strict";(()=>{var e={};e.id=319,e.ids=[319],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},8640:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>$,patchFetch:()=>E,requestAsyncStorage:()=>A,routeModule:()=>S,serverHooks:()=>w,staticGenerationAsyncStorage:()=>R});var a={};r.r(a),r.d(a,{POST:()=>P,dynamic:()=>g,maxDuration:()=>y});var n=r(9303),i=r(8716),o=r(670),s=r(7070),c=r(6794);let l=process.env.NARA_BASE_URL||"https://router.bynara.id/v1",u=process.env.NARA_API_KEY||"",d=["agnes-2.5-flash"];function p(e,t=1){if("string"==typeof e)return e;if("object"!=typeof e||null===e)return String(e);let r="";if(Array.isArray(e)){for(let a of e)"object"==typeof a&&null!==a?r+=p(a,t)+"\n\n":r+=`- ${a}
`;return r}for(let[a,n]of Object.entries(e)){let e=a.replace(/_/g," ").replace(/([A-Z])/g," $1").replace(/^./,e=>e.toUpperCase()).trim(),i="#".repeat(Math.min(t+1,4));if("string"==typeof n)r+=`${i} ${e}

${n}

`;else if(Array.isArray(n)){if(r+=`${i} ${e}

`,n.length>0&&"object"==typeof n[0]&&null!==n[0]){let e=Object.keys(n[0]);if(e.length<=4){for(let t of(r+=`| ${e.map(e=>e.replace(/_/g," ").toUpperCase()).join(" | ")} |
| ${e.map(()=>"---").join(" | ")} |
`,n))r+=`| ${e.map(e=>String(t[e]||"")).join(" | ")} |
`;r+="\n"}else for(let e of n)r+=p(e,t+1)+"\n"}else{for(let e of n)r+=`- ${String(e)}
`;r+="\n"}}else"object"==typeof n&&null!==n?r+=`${i} ${e}

`+p(n,t+1):r+=`${i} ${e}: **${String(n)}**

`}return r}function m(e){if(!e)return"";if("object"==typeof e)return p(e);let t=String(e).trim();if(t.startsWith("```json")&&t.endsWith("```")){let e=t.replace(/^```json\s*/i,"").replace(/```\s*$/,"").trim();try{let t=JSON.parse(e);return m(t)}catch(r){t=e}}if(t.startsWith("{")&&t.endsWith("}")||t.startsWith("[")&&t.endsWith("]"))try{let e=JSON.parse(t);if("object"==typeof e&&null!==e){if(e.overview||e.features||e.uiux||e.technical)return m(e.content||e.overview||p(e));return p(e)}}catch(e){}let r=t.match(/^```(?:markdown|md)?\s*\n([\s\S]*?)\n```$/i);return r&&r[1]?t=r[1].trim():(t.startsWith("```markdown")||t.startsWith("```md"))&&(t=t.replace(/^```(?:markdown|md)?\s*/i,"").replace(/```\s*$/,"").trim()),t.includes("\\n")&&!t.includes("\n\n")&&(t=t.replace(/\\n/g,"\n").replace(/\\r/g,"").replace(/\\t/g,"	").replace(/\\"/g,'"')),t}function f(e,t){let r=(0,c.F)({idea:e.oneLinePitch||e.appName||"Product Concept",platform:e.platform,customPlatform:e.customPlatform,stack:{frontend:e.frontendPreference,backend:e.backendPreference,database:e.databasePreference},designStyle:e.designAesthetic,colors:e.primaryColor?{primary:e.primaryColor,secondary:"#64748b",accent:"#3b82f6",background:"#ffffff",surface:"#f8fafc",text:"#0f172a"}:void 0,keyFeatures:e.keyFeatures,guidingNotes:e.specialRules});return{success:!0,modelUsed:"local-synthesis-engine",projectName:r.projectName||t,isFallback:!0,sections:r.sections.map(e=>({id:e.id,title:e.title,filename:e.filename,content:m(e.content)}))}}async function h(e){let t=e.appName||e.oneLinePitch.substring(0,45)||"AI Generated Project";if(!u)return console.warn("[Nara Router] NARA_API_KEY is not set. Using local synthesis fallback."),f(e,t);let r=e.customPlatform||e.platform||"Cross-Platform Web & Mobile",a=e.frontendPreference||"Modern Reactive Frontend",n=e.backendPreference||"High-Throughput Node.js/Serverless API",i=e.databasePreference||"PostgreSQL",o=`You are a Principal Software Architect and Staff Technical Product Manager.
Generate an elite, developer-ready 4-file Product Requirements Document (PRD) package.
Your output must be returned STRICTLY as a valid JSON object matching this schema:
{
  "overview": "Complete Markdown for 01-PRODUCT-OVERVIEW.md",
  "features": "Complete Markdown for 02-FEATURES-REQUIREMENTS.md",
  "uiux": "Complete Markdown for 03-UI-UX-REQUIREMENTS.md",
  "technical": "Complete Markdown for 04-TECHNICAL-REQUIREMENTS.md"
}

CRITICAL RULES:
- Output MUST be valid JSON containing all 4 keys.
- Each value MUST be direct Markdown text. Do NOT wrap values in triple backticks code fences (do NOT use \`\`\`markdown ... \`\`\` inside JSON values).
- Ensure all quotes and newlines inside JSON strings are properly escaped.
- Be concise, high-density, and technical (~250-400 words per section).

Section Requirements:
1. "overview": Executive Summary, Problem Statement, Target User Personas with JTBD, 3 Core Value Pillars, and a 90-Day Success Metrics KPI Table.
2. "features": Scope Boundary Matrix (MVP vs Phase 2) with P0/P1/P2 priorities, 4-5 Detailed User Stories with Gherkin Acceptance Criteria, Edge Cases & Error States.
3. "uiux": Visual Design System for "${e.designAesthetic}" style, Color Tokens table with exact Hex codes (primary: ${e.primaryColor||"#f97316"}), Typography scale, ASCII Wireframe layout, WCAG AA compliance.
4. "technical": Architecture Blueprint with a Mermaid.js flowchart (graph TD), Production Database Schema (DDL SQL) with foreign keys & indexes, Core REST API contracts with JSON payloads, Security & Auth strategy.`,s=Array.isArray(e.coreUserFlows)&&e.coreUserFlows.length>0?e.coreUserFlows.join("; "):e.coreUserFlows||"Standard user onboarding and core workflow",c=Array.isArray(e.keyFeatures)&&e.keyFeatures.length>0?e.keyFeatures.join("; "):e.keyFeatures||"Core product features and user dashboard",p=Array.isArray(e.thirdPartyIntegrations)&&e.thirdPartyIntegrations.length>0?e.thirdPartyIntegrations.join(", "):e.thirdPartyIntegrations||"Standard REST APIs",h=`Product Idea: ${e.appName||"Application"}
Elevator Pitch: ${e.oneLinePitch||""}
Target Audience: ${e.targetAudience||"General Users"}
Primary Persona Needs: ${e.primaryPersonaNeeds||"High usability, fast performance"}
Core Workflows: ${s}
Key Features: ${c}
Platform: ${r}
Frontend Tech: ${a}
Backend Tech: ${n}
Database: ${i}
Third-Party Integrations: ${p}
Monetization: ${e.monetizationModel||"Standard"}
Design Aesthetic: ${e.designAesthetic||"Minimal"}
Color Mood / Primary: ${e.primaryColor||e.colorMood||"#f97316"}
Special Rules & Constraints: ${e.specialRules||"None specified"}`,g=null;for(let e of d)try{console.log(`[Nara Router] Attempting generation with live model: ${e}`);let r=new AbortController,a=setTimeout(()=>r.abort(),16e3),n=await fetch(`${l}/chat/completions`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${u}`},body:JSON.stringify({model:e,messages:[{role:"system",content:o},{role:"user",content:h}],max_tokens:2200,temperature:.2}),signal:r.signal});if(clearTimeout(a),!n.ok){let t=await n.text();console.warn(`[Nara Router] Model ${e} returned HTTP ${n.status}: ${t.substring(0,100)}`);continue}let i=await n.json(),s=i.choices?.[0]?.message?.content;if(!s){console.warn(`[Nara Router] Model ${e} returned empty choices payload`);continue}let c=function(e){try{let t=function(e){let t=e.trim();if(t.includes("```")){let e=t.match(/```(?:json)?\s*([\s\S]*?)\s*```/);e&&e[1]&&(t=e[1].trim())}try{return JSON.parse(t)}catch(n){let r=t.indexOf("{"),a=t.lastIndexOf("}");if(-1!==r&&-1!==a&&a>r)try{return JSON.parse(t.substring(r,a+1))}catch(e){}throw Error("Unable to parse JSON structure from AI output: "+e.substring(0,150))}}(e);if(t&&(t.overview||t.features||t.uiux||t.technical))return t}catch(e){}let t={},r=e.match(/(?:#+\s*(?:01[ -]?)?PRODUCT[ -]?OVERVIEW[\s\S]*?)(?=#+\s*(?:02[ -]?)?FEATURES|$)/i);r&&(t.overview=r[0].trim());let a=e.match(/(?:#+\s*(?:02[ -]?)?FEATURES[\s\S]*?)(?=#+\s*(?:03[ -]?)?UI|$)/i);a&&(t.features=a[0].trim());let n=e.match(/(?:#+\s*(?:03[ -]?)?UI[\s\S]*?)(?=#+\s*(?:04[ -]?)?TECH|$)/i);n&&(t.uiux=n[0].trim());let i=e.match(/(?:#+\s*(?:04[ -]?)?TECH[\s\S]*?)$/i);return(i&&(t.technical=i[0].trim()),t.overview&&t.features&&t.uiux&&t.technical)?t:null}(s);if(!c||!c.overview||!c.features||!c.uiux||!c.technical){console.warn(`[Nara Router] Model ${e} returned content missing required sections`);continue}return console.log(`[Nara Router] Successfully generated PRD package with model: ${e}`),{success:!0,modelUsed:e,projectName:t,isFallback:!1,sections:[{id:"overview",title:"Product Overview",filename:"01-PRODUCT-OVERVIEW.md",content:m(c.overview)},{id:"features",title:"Features & Requirements",filename:"02-FEATURES-REQUIREMENTS.md",content:m(c.features)},{id:"uiux",title:"UI/UX Requirements",filename:"03-UI-UX-REQUIREMENTS.md",content:m(c.uiux)},{id:"technical",title:"Technical Requirements",filename:"04-TECHNICAL-REQUIREMENTS.md",content:m(c.technical)}]}}catch(t){console.warn(`[Nara Router] Failure with model ${e}:`,t.message),g=t}return console.warn(`[Nara Router] AI model failed or timed out (${g?.message||"timeout"}). Returning high-fidelity local synthesis.`),f(e,t)}let g="force-dynamic",y=25;async function P(e){try{let t=await e.json();if(!t.appName&&!t.oneLinePitch)return s.NextResponse.json({error:"App name or one-line pitch is required"},{status:400});let r=await h(t);return s.NextResponse.json(r,{status:200})}catch(e){return console.error("[API generate-ai error]:",e),s.NextResponse.json({error:"Internal server error during AI generation",details:e.message},{status:500})}}let S=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/prd/generate-ai/route",pathname:"/api/prd/generate-ai",filename:"route",bundlePath:"app/api/prd/generate-ai/route"},resolvedPagePath:"/home/surya/Documents/Projects/PRD/app/api/prd/generate-ai/route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:A,staticGenerationAsyncStorage:R,serverHooks:w}=S,$="/api/prd/generate-ai/route";function E(){return(0,o.patchFetch)({serverHooks:w,staticGenerationAsyncStorage:R})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[948,972,794],()=>r(8640));module.exports=a})();