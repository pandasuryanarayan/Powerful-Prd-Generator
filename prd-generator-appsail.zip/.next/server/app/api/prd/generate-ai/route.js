"use strict";(()=>{var e={};e.id=319,e.ids=[319],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},8640:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>w,patchFetch:()=>A,requestAsyncStorage:()=>S,routeModule:()=>y,serverHooks:()=>R,staticGenerationAsyncStorage:()=>P});var a={};r.r(a),r.d(a,{POST:()=>g,dynamic:()=>f,maxDuration:()=>h});var n=r(9303),i=r(8716),o=r(670),s=r(7070);let l=process.env.NARA_BASE_URL||"https://router.bynara.id/v1",c=process.env.NARA_API_KEY||"",u=["agnes-2.5-flash","laguna-s-2.1","ling-3.0-flash-fin-free","stepfun-3.7-flash"];function d(e,t=1){if("string"==typeof e)return e;if("object"!=typeof e||null===e)return String(e);let r="";if(Array.isArray(e)){for(let a of e)"object"==typeof a&&null!==a?r+=d(a,t)+"\n\n":r+=`- ${a}
`;return r}for(let[a,n]of Object.entries(e)){let e=a.replace(/_/g," ").replace(/([A-Z])/g," $1").replace(/^./,e=>e.toUpperCase()).trim(),i="#".repeat(Math.min(t+1,4));if("string"==typeof n)r+=`${i} ${e}

${n}

`;else if(Array.isArray(n)){if(r+=`${i} ${e}

`,n.length>0&&"object"==typeof n[0]&&null!==n[0]){let e=Object.keys(n[0]);if(e.length<=4){for(let t of(r+=`| ${e.map(e=>e.replace(/_/g," ").toUpperCase()).join(" | ")} |
| ${e.map(()=>"---").join(" | ")} |
`,n))r+=`| ${e.map(e=>String(t[e]||"")).join(" | ")} |
`;r+="\n"}else for(let e of n)r+=d(e,t+1)+"\n"}else{for(let e of n)r+=`- ${String(e)}
`;r+="\n"}}else"object"==typeof n&&null!==n?r+=`${i} ${e}

`+d(n,t+1):r+=`${i} ${e}: **${String(n)}**

`}return r}function p(e){if(!e)return"";if("object"==typeof e)return d(e);let t=String(e).trim();if(t.startsWith("```json")&&t.endsWith("```")){let e=t.replace(/^```json\s*/i,"").replace(/```\s*$/,"").trim();try{let t=JSON.parse(e);return p(t)}catch(r){t=e}}if(t.startsWith("{")&&t.endsWith("}")||t.startsWith("[")&&t.endsWith("]"))try{let e=JSON.parse(t);if("object"==typeof e&&null!==e){if(e.overview||e.features||e.uiux||e.technical)return p(e.content||e.overview||d(e));return d(e)}}catch(e){}let r=t.match(/^```(?:markdown|md)?\s*\n([\s\S]*?)\n```$/i);return r&&r[1]?t=r[1].trim():(t.startsWith("```markdown")||t.startsWith("```md"))&&(t=t.replace(/^```(?:markdown|md)?\s*/i,"").replace(/```\s*$/,"").trim()),t.includes("\\n")&&!t.includes("\n\n")&&(t=t.replace(/\\n/g,"\n").replace(/\\r/g,"").replace(/\\t/g,"	").replace(/\\"/g,'"')),t}async function m(e){let t=e.appName||e.oneLinePitch.substring(0,45)||"AI Generated Project";if(!c)return{success:!1,modelUsed:"none",projectName:t,sections:[],error:"Nara API key not configured. Please set NARA_API_KEY in your environment variables (.env)."};let r=e.customPlatform||e.platform||"Cross-Platform Web & Mobile",a=e.frontendPreference||"Modern Reactive Frontend",n=e.backendPreference||"High-Throughput Node.js/Serverless API",i=e.databasePreference||"PostgreSQL",o=`You are a Principal Software Architect and Staff Technical Product Manager.
Generate an elite, top-tier, implementation-ready 4-file Product Requirements Document (PRD) package.
Your output must be returned STRICTLY as a valid JSON object matching this schema:
{
  "overview": "Complete Markdown for 01-PRODUCT-OVERVIEW.md",
  "features": "Complete Markdown for 02-FEATURES-REQUIREMENTS.md",
  "uiux": "Complete Markdown for 03-UI-UX-REQUIREMENTS.md",
  "technical": "Complete Markdown for 04-TECHNICAL-REQUIREMENTS.md"
}

IMPORTANT INSTRUCTIONS:
- Each value MUST be human-readable Markdown text directly.
- Do NOT wrap the markdown values in triple backticks code fences (do NOT use \`\`\`markdown ... \`\`\` inside JSON strings).
- Ensure all quotes and newlines inside JSON strings are properly formatted.

Quality Requirements:
1. "overview": Executive Summary, Problem Statement with market friction, Target User Personas with Jobs-To-Be-Done, 3 Core Value Pillars, and a 90-Day Success Metrics & Quantitative KPIs Table.
2. "features": Scope Boundary Matrix (MVP vs Phase 2) with P0/P1/P2 priorities, Detailed User Stories in Gherkin Given-When-Then syntax with concrete acceptance criteria, Edge Cases, Boundary Conditions, and Error Recovery States.
3. "uiux": Visual Design System for "${e.designAesthetic}" style, Color Tokens table with exact Hex codes (primary: ${e.primaryColor||"#f97316"}, secondary, accent, bg, surface, text), Typography Scale, ASCII Wireframe layout of key screen, and WCAG accessibility guidelines.
4. "technical": Architecture Blueprint with a Mermaid.js flowchart (graph TD), Production Database Schema (DDL SQL) with foreign keys, constraints, and indexes, Core REST API contracts with JSON request and response payloads, Security & Auth strategy, and Deployment plan.`,s=Array.isArray(e.coreUserFlows)&&e.coreUserFlows.length>0?e.coreUserFlows.join("; "):e.coreUserFlows||"Standard user onboarding and core workflow",d=Array.isArray(e.keyFeatures)&&e.keyFeatures.length>0?e.keyFeatures.join("; "):e.keyFeatures||"Core product features and user dashboard",m=Array.isArray(e.thirdPartyIntegrations)&&e.thirdPartyIntegrations.length>0?e.thirdPartyIntegrations.join(", "):e.thirdPartyIntegrations||"Standard REST APIs",f=`Product Idea: ${e.appName||"Application"}
Elevator Pitch: ${e.oneLinePitch||""}
Target Audience: ${e.targetAudience||"General Users"}
Primary Persona Needs: ${e.primaryPersonaNeeds||"High usability, fast performance"}
Core Workflows: ${s}
Key Features: ${d}
Platform: ${r}
Frontend Tech: ${a}
Backend Tech: ${n}
Database: ${i}
Third-Party Integrations: ${m}
Monetization: ${e.monetizationModel||"Standard"}
Design Aesthetic: ${e.designAesthetic||"Minimal"}
Color Mood / Primary: ${e.primaryColor||e.colorMood||"#f97316"}
Special Rules & Constraints: ${e.specialRules||"None specified"}`,h=null;for(let e of u)try{console.log(`[Nara Router] Attempting generation with live model: ${e}`);let r=new AbortController,a=setTimeout(()=>r.abort(),6e4),n=await fetch(`${l}/chat/completions`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${c}`},body:JSON.stringify({model:e,messages:[{role:"system",content:o},{role:"user",content:f}],temperature:.3}),signal:r.signal});if(clearTimeout(a),!n.ok){let t=await n.text();console.warn(`[Nara Router] Model ${e} returned HTTP ${n.status}: ${t.substring(0,100)}`);continue}let i=await n.json(),s=i.choices?.[0]?.message?.content;if(!s){console.warn(`[Nara Router] Model ${e} returned empty choices payload`);continue}let u=function(e){try{let t=function(e){let t=e.trim();if(t.includes("```")){let e=t.match(/```(?:json)?\s*([\s\S]*?)\s*```/);e&&e[1]&&(t=e[1].trim())}try{return JSON.parse(t)}catch(n){let r=t.indexOf("{"),a=t.lastIndexOf("}");if(-1!==r&&-1!==a&&a>r)try{return JSON.parse(t.substring(r,a+1))}catch(e){}throw Error("Unable to parse JSON structure from AI output: "+e.substring(0,150))}}(e);if(t&&(t.overview||t.features||t.uiux||t.technical))return t}catch(e){}let t={},r=e.match(/(?:#+\s*(?:01[ -]?)?PRODUCT[ -]?OVERVIEW[\s\S]*?)(?=#+\s*(?:02[ -]?)?FEATURES|$)/i);r&&(t.overview=r[0].trim());let a=e.match(/(?:#+\s*(?:02[ -]?)?FEATURES[\s\S]*?)(?=#+\s*(?:03[ -]?)?UI|$)/i);a&&(t.features=a[0].trim());let n=e.match(/(?:#+\s*(?:03[ -]?)?UI[\s\S]*?)(?=#+\s*(?:04[ -]?)?TECH|$)/i);n&&(t.uiux=n[0].trim());let i=e.match(/(?:#+\s*(?:04[ -]?)?TECH[\s\S]*?)$/i);return(i&&(t.technical=i[0].trim()),t.overview&&t.features&&t.uiux&&t.technical)?t:null}(s);if(!u||!u.overview||!u.features||!u.uiux||!u.technical){console.warn(`[Nara Router] Model ${e} returned content missing required sections`);continue}return console.log(`[Nara Router] Successfully generated PRD package with model: ${e}`),{success:!0,modelUsed:e,projectName:t,sections:[{id:"overview",title:"Product Overview",filename:"01-PRODUCT-OVERVIEW.md",content:p(u.overview)},{id:"features",title:"Features & Requirements",filename:"02-FEATURES-REQUIREMENTS.md",content:p(u.features)},{id:"uiux",title:"UI/UX Requirements",filename:"03-UI-UX-REQUIREMENTS.md",content:p(u.uiux)},{id:"technical",title:"Technical Requirements",filename:"04-TECHNICAL-REQUIREMENTS.md",content:p(u.technical)}]}}catch(t){console.warn(`[Nara Router] Failure with model ${e}:`,t.message),h=t}return{success:!1,modelUsed:"none",projectName:t,sections:[],error:h?.message||"All Nara Router models were unavailable."}}let f="force-dynamic",h=60;async function g(e){try{let t=await e.json();if(!t.appName&&!t.oneLinePitch)return s.NextResponse.json({error:"App name or one-line pitch is required"},{status:400});let r=await m(t);if(!r.success)return s.NextResponse.json({error:r.error||"Failed to generate PRD with Nara Router models",details:"All models failed or timed out"},{status:502});return s.NextResponse.json(r)}catch(e){return console.error("[API generate-ai error]:",e),s.NextResponse.json({error:"Internal server error during AI generation",details:e.message},{status:500})}}let y=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/prd/generate-ai/route",pathname:"/api/prd/generate-ai",filename:"route",bundlePath:"app/api/prd/generate-ai/route"},resolvedPagePath:"/home/surya/Documents/Projects/PRD/app/api/prd/generate-ai/route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:S,staticGenerationAsyncStorage:P,serverHooks:R}=y,w="/api/prd/generate-ai/route";function A(){return(0,o.patchFetch)({serverHooks:R,staticGenerationAsyncStorage:P})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[948,972],()=>r(8640));module.exports=a})();