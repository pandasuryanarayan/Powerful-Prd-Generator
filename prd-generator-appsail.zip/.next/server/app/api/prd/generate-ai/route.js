"use strict";(()=>{var e={};e.id=319,e.ids=[319],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},8640:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>P,patchFetch:()=>R,requestAsyncStorage:()=>g,routeModule:()=>h,serverHooks:()=>S,staticGenerationAsyncStorage:()=>y});var n={};r.r(n),r.d(n,{POST:()=>f});var a=r(9303),i=r(8716),o=r(670),s=r(7070);let l=process.env.NARA_BASE_URL||"https://router.bynara.id/v1",c=process.env.NARA_API_KEY||"",u=["agnes-2.5-flash","laguna-s-2.1","ling-3.0-flash-fin-free","stepfun-3.7-flash"];function d(e,t=1){if("string"==typeof e)return e;if("object"!=typeof e||null===e)return String(e);let r="";if(Array.isArray(e)){for(let n of e)"object"==typeof n&&null!==n?r+=d(n,t)+"\n\n":r+=`- ${n}
`;return r}for(let[n,a]of Object.entries(e)){let e=n.replace(/_/g," ").replace(/([A-Z])/g," $1").replace(/^./,e=>e.toUpperCase()).trim(),i="#".repeat(Math.min(t+1,4));if("string"==typeof a)r+=`${i} ${e}

${a}

`;else if(Array.isArray(a)){if(r+=`${i} ${e}

`,a.length>0&&"object"==typeof a[0]&&null!==a[0]){let e=Object.keys(a[0]);if(e.length<=4){for(let t of(r+=`| ${e.map(e=>e.replace(/_/g," ").toUpperCase()).join(" | ")} |
| ${e.map(()=>"---").join(" | ")} |
`,a))r+=`| ${e.map(e=>String(t[e]||"")).join(" | ")} |
`;r+="\n"}else for(let e of a)r+=d(e,t+1)+"\n"}else{for(let e of a)r+=`- ${String(e)}
`;r+="\n"}}else"object"==typeof a&&null!==a?r+=`${i} ${e}

`+d(a,t+1):r+=`${i} ${e}: **${String(a)}**

`}return r}function p(e){if(!e)return"";if("object"==typeof e)return d(e);let t=String(e).trim();if(t.startsWith("```json")&&t.endsWith("```")){let e=t.replace(/^```json\s*/i,"").replace(/```\s*$/,"").trim();try{let t=JSON.parse(e);return p(t)}catch(r){t=e}}if(t.startsWith("{")&&t.endsWith("}")||t.startsWith("[")&&t.endsWith("]"))try{let e=JSON.parse(t);if("object"==typeof e&&null!==e){if(e.overview||e.features||e.uiux||e.technical)return p(e.content||e.overview||d(e));return d(e)}}catch(e){}let r=t.match(/^```(?:markdown|md)?\s*\n([\s\S]*?)\n```$/i);return r&&r[1]?t=r[1].trim():(t.startsWith("```markdown")||t.startsWith("```md"))&&(t=t.replace(/^```(?:markdown|md)?\s*/i,"").replace(/```\s*$/,"").trim()),t.includes("\\n")&&!t.includes("\n\n")&&(t=t.replace(/\\n/g,"\n").replace(/\\r/g,"").replace(/\\t/g,"	").replace(/\\"/g,'"')),t}async function m(e){let t=e.appName||e.oneLinePitch.substring(0,45)||"AI Generated Project";if(!c)return{success:!1,modelUsed:"none",projectName:t,sections:[],error:"Nara API key not configured. Please set NARA_API_KEY in your environment variables (.env)."};let r=e.customPlatform||e.platform||"Cross-Platform Web & Mobile",n=e.frontendPreference||"Modern Reactive Frontend",a=e.backendPreference||"High-Throughput Node.js/Serverless API",i=e.databasePreference||"PostgreSQL",o=`You are a Principal Software Architect and Staff Technical Product Manager.
Generate an elite, top-tier, implementation-ready 4-file Product Requirements Document (PRD) package.
Your output must be returned STRICTLY as a valid JSON object matching this schema:
{
  "overview": "Complete Markdown for 01-PRODUCT-OVERVIEW.md",
  "features": "Complete Markdown for 02-FEATURES-REQUIREMENTS.md",
  "uiux": "Complete Markdown for 03-UI-UX-REQUIREMENTS.md",
  "technical": "Complete Markdown for 04-TECHNICAL-REQUIREMENTS.md"
}

IMPORTANT INSTRUCTIONS:
- Each value MUST be human-readable Markdown text directly.
- Do NOT wrap the markdown values in triple backticks code fences (do NOT use \`\`\`markdown ... \`\`\` inside JSON strings).
- Ensure all quotes and newlines inside JSON strings are properly formatted.

Quality Requirements:
1. "overview": Executive Summary, Problem Statement with market friction, Target User Personas with Jobs-To-Be-Done, 3 Core Value Pillars, and a 90-Day Success Metrics & Quantitative KPIs Table.
2. "features": Scope Boundary Matrix (MVP vs Phase 2) with P0/P1/P2 priorities, Detailed User Stories in Gherkin Given-When-Then syntax with concrete acceptance criteria, Edge Cases, Boundary Conditions, and Error Recovery States.
3. "uiux": Visual Design System for "${e.designAesthetic}" style, Color Tokens table with exact Hex codes (primary: ${e.primaryColor||"#f97316"}, secondary, accent, bg, surface, text), Typography Scale, ASCII Wireframe layout of key screen, and WCAG accessibility guidelines.
4. "technical": Architecture Blueprint with a Mermaid.js flowchart (graph TD), Production Database Schema (DDL SQL) with foreign keys, constraints, and indexes, Core REST API contracts with JSON request and response payloads, Security & Auth strategy, and Deployment plan.`,s=`Product Idea: ${e.appName}
Elevator Pitch: ${e.oneLinePitch}
Target Audience: ${e.targetAudience}
Primary Persona Needs: ${e.primaryPersonaNeeds}
Core Workflows: ${e.coreUserFlows.join("; ")}
Key Features: ${e.keyFeatures.join("; ")}
Platform: ${r}
Frontend Tech: ${n}
Backend Tech: ${a}
Database: ${i}
Third-Party Integrations: ${e.thirdPartyIntegrations.join(", ")}
Monetization: ${e.monetizationModel||"Standard"}
Design Aesthetic: ${e.designAesthetic}
Color Mood / Primary: ${e.primaryColor||e.colorMood||"#f97316"}
Special Rules & Constraints: ${e.specialRules||"None specified"}`,d=null;for(let e of u)try{console.log(`[Nara Router] Attempting generation with live model: ${e}`);let r=new AbortController,n=setTimeout(()=>r.abort(),6e4),a=await fetch(`${l}/chat/completions`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${c}`},body:JSON.stringify({model:e,messages:[{role:"system",content:o},{role:"user",content:s}],temperature:.3}),signal:r.signal});if(clearTimeout(n),!a.ok){let t=await a.text();console.warn(`[Nara Router] Model ${e} returned HTTP ${a.status}: ${t.substring(0,100)}`);continue}let i=await a.json(),u=i.choices?.[0]?.message?.content;if(!u){console.warn(`[Nara Router] Model ${e} returned empty choices payload`);continue}let d=function(e){try{let t=function(e){let t=e.trim();if(t.includes("```")){let e=t.match(/```(?:json)?\s*([\s\S]*?)\s*```/);e&&e[1]&&(t=e[1].trim())}try{return JSON.parse(t)}catch(a){let r=t.indexOf("{"),n=t.lastIndexOf("}");if(-1!==r&&-1!==n&&n>r)try{return JSON.parse(t.substring(r,n+1))}catch(e){}throw Error("Unable to parse JSON structure from AI output: "+e.substring(0,150))}}(e);if(t&&(t.overview||t.features||t.uiux||t.technical))return t}catch(e){}let t={},r=e.match(/(?:#+\s*(?:01[ -]?)?PRODUCT[ -]?OVERVIEW[\s\S]*?)(?=#+\s*(?:02[ -]?)?FEATURES|$)/i);r&&(t.overview=r[0].trim());let n=e.match(/(?:#+\s*(?:02[ -]?)?FEATURES[\s\S]*?)(?=#+\s*(?:03[ -]?)?UI|$)/i);n&&(t.features=n[0].trim());let a=e.match(/(?:#+\s*(?:03[ -]?)?UI[\s\S]*?)(?=#+\s*(?:04[ -]?)?TECH|$)/i);a&&(t.uiux=a[0].trim());let i=e.match(/(?:#+\s*(?:04[ -]?)?TECH[\s\S]*?)$/i);return(i&&(t.technical=i[0].trim()),t.overview&&t.features&&t.uiux&&t.technical)?t:null}(u);if(!d||!d.overview||!d.features||!d.uiux||!d.technical){console.warn(`[Nara Router] Model ${e} returned content missing required sections`);continue}return console.log(`[Nara Router] Successfully generated PRD package with model: ${e}`),{success:!0,modelUsed:e,projectName:t,sections:[{id:"overview",title:"Product Overview",filename:"01-PRODUCT-OVERVIEW.md",content:p(d.overview)},{id:"features",title:"Features & Requirements",filename:"02-FEATURES-REQUIREMENTS.md",content:p(d.features)},{id:"uiux",title:"UI/UX Requirements",filename:"03-UI-UX-REQUIREMENTS.md",content:p(d.uiux)},{id:"technical",title:"Technical Requirements",filename:"04-TECHNICAL-REQUIREMENTS.md",content:p(d.technical)}]}}catch(t){console.warn(`[Nara Router] Failure with model ${e}:`,t.message),d=t}return{success:!1,modelUsed:"none",projectName:t,sections:[],error:d?.message||"All Nara Router models were unavailable."}}async function f(e){try{let t=await e.json();if(!t.appName&&!t.oneLinePitch)return s.NextResponse.json({error:"App name or one-line pitch is required"},{status:400});let r=await m(t);if(!r.success)return s.NextResponse.json({error:r.error||"Failed to generate PRD with Nara Router models",details:"All models failed or timed out"},{status:502});return s.NextResponse.json(r)}catch(e){return console.error("[API generate-ai error]:",e),s.NextResponse.json({error:"Internal server error during AI generation",details:e.message},{status:500})}}let h=new a.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/prd/generate-ai/route",pathname:"/api/prd/generate-ai",filename:"route",bundlePath:"app/api/prd/generate-ai/route"},resolvedPagePath:"/home/surya/Documents/Projects/PRD/app/api/prd/generate-ai/route.ts",nextConfigOutput:"standalone",userland:n}),{requestAsyncStorage:g,staticGenerationAsyncStorage:y,serverHooks:S}=h,P="/api/prd/generate-ai/route";function R(){return(0,o.patchFetch)({serverHooks:S,staticGenerationAsyncStorage:y})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[948,972],()=>r(8640));module.exports=n})();