(()=>{var e={};e.id=271,e.ids=[271],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},4300:e=>{"use strict";e.exports=require("buffer")},2361:e=>{"use strict";e.exports=require("events")},2781:e=>{"use strict";e.exports=require("stream")},3837:e=>{"use strict";e.exports=require("util")},3627:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>i.a,__next_app__:()=>p,originalPathname:()=>u,pages:()=>d,routeModule:()=>m,tree:()=>l}),s(1177),s(5980),s(9245),s(5866);var r=s(3191),a=s(8716),n=s(7922),i=s.n(n),o=s(5231),c={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(c[e]=()=>o[e]);s.d(t,c);let l=["",{children:["create",{children:["generating",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,1177)),"/home/surya/Documents/Projects/PRD/app/create/generating/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(s.bind(s,5980)),"/home/surya/Documents/Projects/PRD/app/create/layout.tsx"]}]},{layout:[()=>Promise.resolve().then(s.bind(s,9245)),"/home/surya/Documents/Projects/PRD/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,5866,23)),"next/dist/client/components/not-found-error"]}],d=["/home/surya/Documents/Projects/PRD/app/create/generating/page.tsx"],u="/create/generating/page",p={require:s,loadChunk:()=>Promise.resolve()},m=new r.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/create/generating/page",pathname:"/create/generating",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:l}})},141:(e,t,s)=>{Promise.resolve().then(s.bind(s,1405))},5303:()=>{},1405:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>x});var r=s(326),a=s(7577),n=s(5047),i=s(2881);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,i.Z)("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);var c=s(2933);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,i.Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);var d=s(4230),u=s(4053);s(3645),s(4090),s(8566);var p=s(6904),m=s(3679);function x(){let e=(0,n.useRouter)(),t=(0,p.PV)(e=>e.currentProjectId);(0,p.PV)(e=>e.getProject),(0,p.PV)(e=>e.setSections),(0,p.PV)(e=>e.setStatus),(0,p.PV)(e=>e.updateProject),(0,p.Es)(e=>e.showToast);let[s,i]=(0,a.useState)(0),[x,h]=(0,a.useState)([]),[f,g]=(0,a.useState)(null),[y,b]=(0,a.useState)(!1);(0,a.useRef)(null),(0,a.useRef)(!1);let j=Math.round(x.length/u.ON.length*100);return r.jsx("div",{className:"flex min-h-screen items-center justify-center bg-[#f7f7f5] px-4 py-12",children:(0,r.jsxs)("div",{className:"mx-auto w-full max-w-xl",children:[(0,r.jsxs)("div",{className:"text-center mb-8",children:[r.jsx("div",{className:"mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#fff1e8] text-[#f97316] shadow-sm border border-[#f97316]/20",children:f?r.jsx(o,{size:32,className:"text-red-500"}):y?r.jsx(c.Z,{size:32,className:"text-[#16803c]"}):r.jsx(l,{size:32,className:"animate-spin"})}),r.jsx("h1",{className:"text-[26px] font-bold text-[#171717]",children:f?"Generation Encountered an Issue":y?"PRD Package Complete!":"Generating Developer-Ready PRD"}),r.jsx("p",{className:"mt-1.5 text-sm text-[#6b6b67]",children:f?"You can retry generation or return to edit your configuration.":"Constructing modular 4-file specification and design system tokens..."})]}),(0,r.jsxs)("div",{className:"mb-8 space-y-2",children:[(0,r.jsxs)("div",{className:"flex justify-between text-xs font-semibold text-[#6b6b67]",children:[r.jsx("span",{children:"Pipeline Progress"}),(0,r.jsxs)("span",{className:"text-[#f97316] font-bold",children:[j,"%"]})]}),r.jsx("div",{className:"h-2.5 w-full rounded-full bg-[#deded8] overflow-hidden",children:r.jsx("div",{className:"h-full rounded-full bg-gradient-to-r from-[#f97316] to-[#ea580c] transition-all duration-300 ease-out",style:{width:`${j}%`}})})]}),r.jsx("div",{className:"space-y-2 rounded-2xl border border-[#deded8] bg-white p-5 shadow-sm",children:u.ON.map((e,t)=>{let a=x.includes(e.id),n=t===s&&!f&&!y;return(0,r.jsxs)("div",{className:`flex items-center gap-3.5 px-3 py-2 rounded-xl transition-all ${n?"bg-[#fff1e8] border border-[#f97316]/30":a?"bg-[#fafaf9]":"opacity-50"}`,children:[r.jsx("div",{className:"shrink-0",children:a?r.jsx("div",{className:"w-5 h-5 rounded-full bg-[#16803c] text-white flex items-center justify-center text-xs shadow-xs",children:r.jsx(c.Z,{size:12})}):n?r.jsx("div",{className:"w-5 h-5 rounded-full border-2 border-[#f97316] border-t-transparent animate-spin"}):r.jsx("div",{className:"w-5 h-5 rounded-full border border-[#deded8] bg-white"})}),(0,r.jsxs)("div",{className:"flex-1 min-w-0",children:[r.jsx("p",{className:`text-xs font-semibold truncate ${n?"text-[#c2410c]":a?"text-[#171717]":"text-[#6b6b67]"}`,children:e.label}),r.jsx("p",{className:"text-[10px] text-[#6b6b67] truncate",children:e.description})]}),n&&r.jsx("span",{className:"text-[10px] font-bold text-[#f97316] animate-pulse shrink-0",children:"Running..."}),a&&r.jsx("span",{className:"text-[10px] font-medium text-[#16803c] shrink-0",children:"Done"})]},e.id)})}),f&&(0,r.jsxs)("div",{className:"mt-6 flex justify-center gap-3",children:[r.jsx(m.Z,{variant:"secondary",onClick:()=>e.push("/create"),children:"Back to Builder"}),r.jsx(m.Z,{onClick:()=>window.location.reload(),children:"Try Again"})]}),y&&(0,r.jsxs)("div",{className:"mt-6 text-center space-y-3",children:[(0,r.jsxs)("p",{className:"text-xs text-[#16803c] font-medium flex items-center justify-center gap-1.5",children:[r.jsx(c.Z,{size:14})," ZIP download initiated automatically."]}),r.jsx(m.Z,{size:"md",rightIcon:r.jsx(d.Z,{size:16}),onClick:()=>e.push(`/prd/${t}`),children:"Open Interactive PRD Viewer"})]})]})})}},3679:(e,t,s)=>{"use strict";s.d(t,{Z:()=>o});var r=s(326),a=s(1135);let n={primary:"bg-[#f97316] text-white hover:bg-[#ea580c] focus:ring-2 focus:ring-[#f97316]/20",secondary:"border border-[#deded8] bg-white text-[#171717] hover:bg-[#f1f1ee]",tertiary:"text-[#6b6b67] hover:bg-[#f1f1ee] hover:text-[#171717]",danger:"bg-[#c2410c] text-white hover:bg-[#a84324]"},i={sm:"px-3 py-1.5 text-sm",md:"px-4 py-2 text-sm",lg:"px-6 py-2.5 text-base"};function o({variant:e="primary",size:t="md",loading:s=!1,leftIcon:o,rightIcon:c,children:l,className:d,disabled:u,...p}){return(0,r.jsxs)("button",{className:(0,a.W)("inline-flex items-center justify-center gap-2 rounded-lg font-medium transition-colors focus:outline-none disabled:cursor-not-allowed disabled:opacity-50",n[e],i[t],d),disabled:u||s,...p,children:[s&&(0,r.jsxs)("svg",{className:"h-4 w-4 animate-spin",viewBox:"0 0 24 24",fill:"none",children:[r.jsx("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"3"}),r.jsx("path",{className:"opacity-90",d:"M4 12a8 8 0 0 1 8-8V0C5.373 0 0 5.373 0 12h4z",fill:"currentColor"})]}),!s&&o,l,c]})}},3645:(e,t,s)=>{"use strict";s.d(t,{a:()=>a,l:()=>n});var r=s(8566);async function a(e){let t=new(await s.e(722).then(s.t.bind(s,9722,23))).default,a=e.title.replace(/[^\w\s-]/gi,"").trim()||"Product-PRD",n=`${a.toLowerCase().replace(/\s+/g,"-")}-prd-package`,i=t.folder(n)||t;e.sections.forEach(e=>{let t=e.filename||`${e.title.toLowerCase().replace(/[^\w]/g,"-")}.md`;i.file(t,(0,r.J9)(e.content))});let o=`# ${e.title} — Master Product Requirements Document

> **Target Platform**: ${e.input.platform||"Web"}  
> **Tech Stack**: ${e.input.stack?.frontend||"React"} + ${e.input.stack?.backend||"Node.js"} + ${e.input.stack?.database||"SQL"}  
> **Visual Style**: ${e.input.designStyle||"Minimal"}  
> **Typography**: ${e.input.font||"Poppins"}  
> **Generated**: ${new Date(e.createdAt).toLocaleDateString()}  

---

${e.sections.map(e=>(0,r.J9)(e.content)).join("\n\n---\n\n")}
`;i.file("PRD.md",o);let c=`# ${e.title} — AI PRD Package

Welcome to your developer-ready, 4-file Product Requirements Document package. This structure is specifically optimized for human engineering teams and AI coding agents (Claude Code, Cursor, Copilot, Windsurf).

---

## Package Contents

| File | Purpose |
| :--- | :--- |
| **\`01-PRODUCT-OVERVIEW.md\`** | Executive summary, problem statement, personas, and success metrics. |
| **\`02-FEATURES-REQUIREMENTS.md\`** | Feature matrix (MVP vs Phase 2), user stories with Given-When-Then acceptance criteria, edge cases. |
| **\`03-UI-UX-REQUIREMENTS.md\`** | Design system specifications, design tokens, color palette hex codes, typography hierarchy, screen flows. |
| **\`04-TECHNICAL-REQUIREMENTS.md\`** | Architecture blueprint, API endpoints, database schemas, security, and deployment strategy. |
| **\`PRD.md\`** | Master consolidated document containing all 4 sections in a single file. |

---

## How to Use with AI Coding Agents

### 1. Using with Claude Code (Terminal CLI)
Drop these files into your repository's root or \`docs/\` directory. Run:
\`\`\`bash
# Initialize project scaffolding
claude "Read 01-PRODUCT-OVERVIEW.md and 04-TECHNICAL-REQUIREMENTS.md to set up the repository architecture and tech stack."

# Implement features sequentially
claude "Review 02-FEATURES-REQUIREMENTS.md and implement Story 1 with full unit test coverage."
\`\`\`

### 2. Using with Cursor / Composer
Reference the specific requirement file directly into your Composer prompt (\`Ctrl/Cmd + I\`):
\`\`\`
@04-TECHNICAL-REQUIREMENTS.md @02-FEATURES-REQUIREMENTS.md 
Please scaffold the database schema and API endpoints defined for the project.
\`\`\`

### 3. Using with GitHub Copilot & Windsurf
Open the relevant \`.md\` file in your split editor pane to provide active context memory to the language model while you code.

---

## Architecture Metadata
- **Platform**: \`${e.input.platform||"website"}\`
- **Frontend**: \`${e.input.stack?.frontend||"Next.js"}\`
- **Backend**: \`${e.input.stack?.backend||"Node.js"}\`
- **Database**: \`${e.input.stack?.database||"PostgreSQL"}\`
- **Design System Style**: \`${e.input.designStyle||"Minimal"}\`
- **Theme Mode**: \`${e.input.theme||"both"}\`
- **Primary Typography**: \`${e.input.font||"Poppins"}\`
- **Primary Color**: \`${e.input.colors?.primary||"#3B82F6"}\`
`;return i.file("README.md",c),await t.generateAsync({type:"blob"})}function n(e,t){let s=URL.createObjectURL(e),r=document.createElement("a");r.href=s,r.download=t,document.body.appendChild(r),r.click(),URL.revokeObjectURL(s),r.remove()}},4230:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(2881).Z)("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]])},1177:(e,t,s)=>{"use strict";s.r(t),s.d(t,{$$typeof:()=>i,__esModule:()=>n,default:()=>o});var r=s(8570);let a=(0,r.createProxy)(String.raw`/home/surya/Documents/Projects/PRD/app/create/generating/page.tsx`),{__esModule:n,$$typeof:i}=a;a.default;let o=(0,r.createProxy)(String.raw`/home/surya/Documents/Projects/PRD/app/create/generating/page.tsx#default`)},5980:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>a});var r=s(9510);function a({children:e}){return r.jsx(r.Fragment,{children:e})}}};var t=require("../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[948,513,677,689],()=>s(3627));module.exports=r})();