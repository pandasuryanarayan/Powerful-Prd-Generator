// Zoho Catalyst AppSail Entrypoint
process.env.PORT = process.env.X_ZOHO_CATALYST_LISTEN_PORT || process.env.PORT || '3000';
process.env.HOSTNAME = '0.0.0.0';

console.log(`[AppSail] Starting Next.js server on port ${process.env.PORT} (host: ${process.env.HOSTNAME})...`);

require('./server.js');
